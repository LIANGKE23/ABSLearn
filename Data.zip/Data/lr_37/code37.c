#include <stdio.h>
void main()
 {
     int a = 6;
    int x = a;
    double c[x];
    double * w;
    w = &c;
}