#include <stdio.h>
void main()
 {
    int c[6] = {1,2,3,5,12,3};
    int a = 12;
    int sz = 8;
    printf("%d\n",c[2]);
    int * w;
    w = c + a - sz;
    printf("%d",&w);
}