#include "stdio.h"   /*±ê×¼ÊäÈëÊä³öº¯Êý¿â*/
#include "stdlib.h"  /*±ê×¼º¯Êý¿â*/
#include "string.h"  
struct s{
	int *a;
	int b;
};

int main()
{
	struct s s1, s2;
	struct s * p1;
	int x[1], y;
	s1.a = x;
	s1.b = y;
	s2 = s1;
	return 0;
}