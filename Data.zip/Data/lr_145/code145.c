#include <stdio.h>
#include <stdlib.h>
typedef unsigned long long int uint64_t;
int main()
{
int num[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
int x = 10;
int num1[x];
int * p = &num[0];
int * q = &num1[9];
int temp;

   while ( p < q) {
     temp = *p;
     *p++ = *q;
     *q-- = temp;
  }
}
