#include <stdio.h>

/* doesn't work */
void
doubler(int * x)
{
    *x *= 2;
}

int
main(int argc, char **argv)
{
    int y;

    y = 1;
    int a[2];
    int sz = 2;
    int * p=(int*)malloc(sz*sizeof(int));        /* pointer variable for malloc below */

    doubler(&y);                /* sets y to 2 */

    printf("%d\n", y);          /* prints 2 */

    return 0;
}