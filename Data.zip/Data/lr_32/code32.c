#include <stdio.h>
void main()
 {
    char c[12] = {'1','d','23','sa','00'};
    int a = 15;
    printf("%c\n",c[1]);
    char * w;
    w = c + a - 4;
    printf("%c",w);
}