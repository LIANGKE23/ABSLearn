#include <stdio.h>
void main()
 {
    int a[] = {1, 2,10,21,31,45};
    int * q;
    q = a+2;
}