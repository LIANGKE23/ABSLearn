#include <stdio.h>
#include <stdlib.h>
typedef unsigned long long int uint64_t;
int main()
{
    int a[] = {1, 2, 3, 4, 5};
    int *p = a;
    int *q = p + 3;
    int *w = q+1;
    int k;
    scanf("%d",&k);
    for (int i=0;i<k;i++){
        printf("%d", *w);
        w++;
    }
    return 0;
}
