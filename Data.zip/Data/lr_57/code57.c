#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
char * LXY =(char *)malloc(5*sizeof(char));
scanf("%c",&LXY);
char T;
scanf("%c",&LXY);
char p[6];
char q[6];
char * XY = LXY + 1;
}
