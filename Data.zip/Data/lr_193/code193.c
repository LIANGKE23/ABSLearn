#include <stdio.h>
void main()
{int * p;
 int a;
 int b1[5];
 int b2[10];
 scanf("%d",&a);
 int size;
 if (a<5){p = b1;
          size = 5;}
 else{p = b2;
      size = 10;}
}