#include <stdio.h>
void main()
 {
    int lxy[12];
    printf("%d\n",lxy[0]);
    int * q;
    q = (lxy + 5);
    printf("%d",q);
}