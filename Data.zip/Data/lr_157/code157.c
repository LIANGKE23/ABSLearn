/*creat a list*/
#include "stdlib.h"
#include "stdio.h"
struct list
{ 
	int data;
	struct list * next;
};


void main()
{ 
	struct list * ptr;
	struct list * head;
	int num;
	int i;
	int x = 20;
	ptr=(struct list *)malloc(x*sizeof(struct list));
	ptr=head;
	printf("please input 5 numbers==>\n");
	for(i=0;i<=4;i++){
		scanf("%d",&num);
		ptr->data=num;
		ptr->next=(struct list *)malloc(sizeof(struct list));
		if(i==4){
  			ptr->next=NULL;}
		else{
			ptr=ptr->next;}
		}
	ptr=head;
	while(ptr!=NULL){
		printf("The value is ==>%d\n",ptr->data);
		ptr=ptr->next;}
}