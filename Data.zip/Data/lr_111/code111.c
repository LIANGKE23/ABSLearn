#include <stdio.h>
void main()
 {
    int n = 10;
    int sz = n*10;
    double * p;
    p = (double *)malloc((sizeof(double))*n);
}