#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
char b ="y";
scanf("%c",&b);
printf("%c",&b);
char o[43];
int E[13] = {1,2};
char D[39];
int m = E[0];
char K;
int k[23];
int sz = 1;
char * s =(char *)malloc((m)*sizeof(char));
int J[48];
int * P =(int *)malloc(30*sizeof(int));
}
