#include <stdio.h>
#include <stdlib.h>


struct gl_api_table {
  int* x;
  unsigned y;
  float z;
};


void check_pointers(struct gl_api_table table)
{
  
  int numentries = sizeof( struct gl_api_table ) / sizeof(void*);
  static int * entry;
  int* aaa = (int*)malloc(sizeof(int)*numentries);
  entry = table.x;
}


int main()
{
  struct gl_api_table table;
  check_pointers(table);
  return 0;
}