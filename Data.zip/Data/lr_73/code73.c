#include <stdio.h>
void main()
{
    int a = 5;
    int b = 6;
    int k;
    scanf("%d",&k);
    int * p;
    if (k>5){
        p = (int *)malloc(a*sizeof(int));
    }
    else if (k<2){
        p = (int *)malloc(b*sizeof(int));
        a =b;
        int * c = p;
    }
    else{
        p = (int *)malloc(12*sizeof(int));
        a = 12;
    }
}