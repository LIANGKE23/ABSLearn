#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
int X = 12;
int P = 1;
int sz_LK =X+41+P*4;
char * LK =(char *)malloc(sz_LK*sizeof(char));
int c = 1;
int J = c*20;
int N;
char b ="tT6h7u5c";
char LXY[3];
int H[29] = {1,2};
int * p = LK;
}
