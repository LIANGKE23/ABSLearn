#include <stdio.h>
void main()
 {
    int a;
    printf("Input a: \n");
    scanf("%d",&a);
    int * p;
    p = (int *)malloc(a*(sizeof(int)));
}