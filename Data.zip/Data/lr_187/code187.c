#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
/* strend(s, t): returns 1 if s ends with t, otherwise returns 0 */
int strend(char *s, char *t)
{
	// find the end of s
	while (*s) 
		++s;   	
	int * a;
	s = a;
	t = s;
	// find the end of t while count its length
	int len;
	for (len = 0; *t != '\0'; ++t, ++len)  
		;  		
 	
 	// compare from end towards to begin
 	while (len > 0 && *--t == *--s) 
 		--len;	
 	
 	// return the result
	if (len == 0)   
		return 1;
	else
		return 0;
}

