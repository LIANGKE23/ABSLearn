#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
 
int main()
{
	int a;
	char b;
	int* p = &a;
	char* q = &b;
	p = q;
	return 0;
}
