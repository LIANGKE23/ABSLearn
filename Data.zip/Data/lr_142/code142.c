#include <stdio.h>
#include <stdlib.h>
typedef unsigned long long int uint64_t;
int main(){
    int a[] = {1, 2, 3, 4, 5,3};
    int b[2] = {};
    int *p = a;
    int * q = p + 3;
    int * w = q+2;
    int input;
    int sz;
    int * pp;
    scanf("%d",&input);
    if (input > 10){
        pp = a;
        sz = 5;}
    else{
        pp = b;
        sz = 2;}
    int k;
    scanf("%d",&k);
    for (int i=0;i<k;i++){
        printf("%d", *w);
        w++;}
    return 0;}
