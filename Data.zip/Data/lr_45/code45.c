#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
	char t;
	int C;
	int K = 2;
	char * B;
	char * x =(char *)malloc(45*sizeof(char));
	char * W =(char *)malloc(16*sizeof(char));
	int s;
	char * J =(char *)malloc(9*sizeof(char));
	char * P =x;
	int u;
	char O ="d";
	char N ="N";
	int I;
	int c[29];
	int d[4];
	int * g;
	char * p =(char *)malloc(31*sizeof(char));
	char * f =(char *)malloc(17*sizeof(char));
	char *  __attribute__((annotate("main:v&main:P-alias/main:x-alias/main:U-alias"))) v = P+3;
	int i[8];
	char * L =(char *)malloc(21*sizeof(char));
	char S[19];
	char * __attribute__((annotate("main:U&main:v-alias/main:P-alias/main:x-alias"))) U = v+1;
	int * H =(int *)malloc(14*sizeof(int));
	int * Q =(int *)malloc(18*sizeof(int));
	int * w =(int *)malloc(5*sizeof(int));
}
