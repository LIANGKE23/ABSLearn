#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
char y[19];
int i;
char * B =(char *)malloc(38*sizeof(char));
char X;
int T[25] = {1};
scanf("%d",&i);
int sz_E = T[0]*10;
int * o =(int *)malloc((i)*sizeof(int));
int * E =(int *)malloc(sz_E*sizeof(int));
int g[19]={99,834,325,688,685,160,666,239,510,417,683,823,771,712,230,19,276,876,26};
int J;
scanf("%d",&J);
int * m =(int *)malloc(46*sizeof(int));
char l ="s";
int * S =(int *)malloc(6*sizeof(int));
int * z = E+3;
char e ="sd";
const char ChDay[][10] = {"","初一","初二dao","初三","初四","初五",
 "初六zhi","初七","初八","初九","初十dao",
 "十一","十二","十三版","十四","十五",
 "十六","十七","十八","十九","二十",
 "廿一","廿二权","廿三","廿四","廿五",
 "廿六","廿七","廿八","廿九","三十"
 };
}
