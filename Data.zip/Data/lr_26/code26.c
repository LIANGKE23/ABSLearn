#include <stdio.h>
void main()
 {
    char lk[21];
    int sz = 12;
    char * a;
    a = lk;
}