#include <stdio.h>
void main()
 {
    int n = 10;
    int a = 9;
    int sz = a + 1;
    double * p;
    p = (double *)malloc(n*(sizeof(double)));
}