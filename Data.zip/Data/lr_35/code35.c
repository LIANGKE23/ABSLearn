#include <stdio.h>
void main()
 {
    double c[5] = {1.2,12.3,1.22,0.12};
    int a = 5;
    printf("%d\n",c[1]);
    double * w;
    w = c;
    printf("%d",w);
}
