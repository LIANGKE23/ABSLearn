#include <stdio.h>
void main()
 {
    int a = 6;
    int x = a;
    double c[x];
    int aa = x;
    double * w;
    w = &c;
}