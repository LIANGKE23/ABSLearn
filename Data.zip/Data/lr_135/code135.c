#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

int main(){
    /*asas*/
    int ct = 1;
    int bt =ct;
    int at = bt;
    int bt1[at];
    int ct1  = 2;
    int bt3 =ct1;
    int at1 = bt3;
    int bt2[at1];

    int *p;
    int * q;
    int a;/*asas*/int n = 20;
    int b1[5] = {1,2,3,4,5};
    int b2[10] = {11,2,3,4,5,6,7,8,9,10};
    int *b3 = (int *)malloc(n*sizeof(int*));
    printf("Input a: \n");
    scanf("%d",&a);
    int size_p;
    int size_c2;

    if(a<5){
        size_p = 5;}
    else if((a>=5)&(a<10)){
        size_p = 10;
    }
    else{
        size_p = 20;
    }
    
    if(a<5){
        p = b1;
        printf("p:%d",*p);
        
    }
    else if((a>=5)&(a<10)){
        p = b2;
        q = bt1;
        size_c2 = at;
    }
    else{
        p = b3;
        q = bt2;
    }
    int * c = p+2;
    printf("c:%d",*c);
    return 0;
}