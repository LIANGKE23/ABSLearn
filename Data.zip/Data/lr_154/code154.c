#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_VAR_NAME (20)
#define MAX_NUM_COL (100)
#define MAX_NUM_ROW (1000)


static char *type2str[] = { "int", "int *"};

enum type_t {
    INT = 0,
    UINT64_PTR
};

struct obj_t
{
    char name[MAX_VAR_NAME];
    enum type_t type;
    char val[MAX_NUM_COL];
    int startVal;
    int endVal;
};

struct config_t
{
    char *grid;
    int cur;
    int indent;
};

void prefix(struct config_t * config) 
{
    int cur = config->cur;
    char *ptr = config->grid+cur*MAX_NUM_COL;

    sprintf(ptr, "#include <stdio.h>\n");
    ptr+=MAX_NUM_COL;

    sprintf(ptr, "#include <stdlib.h>\n");
    ptr+=MAX_NUM_COL;

    sprintf(ptr, "#include <string.h>\n");
    ptr+=MAX_NUM_COL;

    sprintf(ptr, "#include <stdint.h>\n\n");
    ptr+=MAX_NUM_COL;

    sprintf(ptr, "int main()\n{\n");
    ptr+=MAX_NUM_COL;

    config->cur += 5;
    config->indent +=4;
}

void postfix(struct config_t * config)
{
    int indent =config->indent;
    int cur = config->cur;
    char *ptr = config->grid+cur*MAX_NUM_COL;
    
    sprintf(ptr + indent, "return 0;\n");
    ptr+=MAX_NUM_COL;

    sprintf(ptr, "}\n");

    config->cur += 2;
}


void initVar(struct config_t * config, struct obj_t * obj)
{
    int indent =config->indent;
    int cur = config->cur;
    char *ptr = config->grid+cur*MAX_NUM_COL;
    
    if(strlen(obj->val))
    {
        sprintf(ptr + indent, "%s %s = %s;\n", type2str[obj->type], obj->name, obj->val);    
    }
    else
    {
        sprintf(ptr + indent, "%s %s;\n", type2str[obj->type], obj->name);    
    }
    
    config->cur ++;
}

void forLoop(struct config_t * config, struct obj_t * obj)
{
    int indent =config->indent;
    int cur = config->cur;
    char *ptr = config->grid+cur*MAX_NUM_COL;

    sprintf(ptr + indent, "for(int %s=%d; %s<%d;%s++) {\n", obj->name, obj->startVal, obj->name, obj->endVal, obj->name);
    
    config->cur++;
    config->indent +=4;
}

void rightBrace(struct config_t * config, struct obj_t * obj)
{
    int indent =config->indent - 4;
    int cur = config->cur;
    char *ptr = config->grid+cur*MAX_NUM_COL;

    sprintf(ptr + indent, "}\n");
    
    config->cur++;
    config->indent -=4;
}

void displayOperation(struct config_t *config, char * input)
{
    int indent =config->indent;
    int cur = config->cur;
    char * ptr = config->grid+cur*MAX_NUM_COL;
    
    sprintf(ptr + indent, "%s;\n", input);

    config->cur++;    
}

// operations
void objIncr(struct obj_t * obj, char * output)
{
    sprintf(output, "%s++", obj->name);
}

void objAddVal(struct obj_t * obj, int val, char * output)
{
    sprintf(output, "%s + %d", obj->name, val);
} 

void objMalloc(struct obj_t * obj,  char * output)
{
    sprintf(output, "malloc(%s)", obj->name);
}

void print(struct config_t * config, struct obj_t * obj, char *format)
{
    int indent =config->indent;
    int cur = config->cur;
    char * ptr = config->grid+cur*MAX_NUM_COL;
    sprintf(ptr + indent, "printf(\"%s\", %s);\n", format, obj->name);
    config->cur++;
}

void dumpGrid(FILE *fp, char (*grid)[MAX_NUM_COL], int numRows)
{
    for(int i=0; i<numRows; i++)
    {   
        fprintf(fp, "%s", grid[i]);
    }
}

int main(int argc, char **argv)
{
    static char grid[MAX_NUM_ROW][MAX_NUM_COL];
    memset(grid, ' ', sizeof(grid));

    FILE * fp;

    if(argc == 2)
    {
        fp=fopen(argv[1], "w+t");
    }
    else
    {
        fp=fopen("Code_20.c", "w+t"); // default output file name
    }

    if (fp==NULL)
    {
        printf("fp==NULL\n");
        return -1;
    }

    struct config_t config;
    config.cur = 0;
    config.grid = (char *)grid;
    config.indent = 0;

    struct obj_t n;
    strcpy(n.name, "n");
    n.type = INT;
    strcpy(n.val,"10");

    struct obj_t pj;
    strcpy(pj.name, "pj");
    pj.type = UINT64_PTR;
    pj.val[0]='\0';

    struct obj_t j;
    strcpy(j.name, "j");
    j.type = UINT64_PTR;
    j.val[0]='\0';

    struct obj_t k;
    strcpy(k.name, "k");
    k.type = INT;
    k.val[0]='\0';
    k.startVal = 0;
    k.endVal = 15;
    
    static char buffer[MAX_NUM_COL];

    prefix(&config);

    initVar(&config, &n);

    objMalloc(&n, j.val);
    initVar(&config, &j);

    objAddVal(&pj, 1, pj.val);
    initVar(&config, &pj);  

    forLoop(&config, &k);
    
    print(&config, &pj, "%d");
    
    objIncr(&pj, buffer);
    displayOperation(&config, buffer);

    rightBrace(&config, &pj);

    postfix(&config);
    
    dumpGrid(fp, grid, config.cur);

    fclose(fp);
    
    return 0;
}