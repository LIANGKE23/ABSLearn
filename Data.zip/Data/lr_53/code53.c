#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
char * B =(char *)malloc(24*sizeof(char));
char e[1]={"6g918SMI"};
char * a = B;
}