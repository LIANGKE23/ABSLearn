#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include "stdlib.h"
#include "stdio.h"
struct list{
	int data;
	int * sb;
	int a[10];
};

int a_int = 10;
int* p_int = &a_int;

int main() {
	struct list ptr;
	ptr.data = a_int;
	ptr.b = ptr.a;
	int b_int = a_int;

	int* q_int = p_int;
	int arr1[]={3,12,8,9,11};

	p_int = arr1;
	return 0;
}
