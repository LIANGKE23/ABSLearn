#include <stdio.h>
void main()
{
    int a = 5;
    int b = a + 6;
    int b1 = b*2;
    int k;
    int k1;
    scanf("%d",&k);
    int * p;
    if (k>5){
        p = (int *)malloc(b*sizeof(int));
        k1 = b;
    }
    else if (k<2){
        p = (int *)malloc(b1*sizeof(int));
        k1= b1;
        int * c = p;
    }
    else{
        k1=12;
        p = (int *)malloc(12*sizeof(int));
    }
}