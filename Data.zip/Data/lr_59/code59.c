#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
char N ="1TmfKMi0";
char LXY;
scanf("%c",N);
char e;
int a;
printf("%c",N);
char W;
int z[]={907,505,433,728,911,305,444,439,610,199,106,177,455,647,297,344,198,240,23};
char B ="CqaovX5i";
int sz = 10;
int * f =(int *)malloc((sz)*sizeof(int));
char w ="zdugvbkt";
int E[6];
}