#include <stdio.h>
void main()
 {
     int a = 6;
    int x = a;
    double c[x];
    int sz = 100;
    double * w;
    w = &c;
}