#include <stdio.h>
void main()
 {
    int p =21;
    char d[2];
    printf("%d\n",p);
    char * q;
    int a = 12;
    q = &d;
    printf("%c",q-1);
}