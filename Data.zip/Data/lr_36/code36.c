#include <stdio.h>
void main()
 {
     int a = 6;
    int x = a +1;
    double c[x];
    double * w;
    w = &c;
}