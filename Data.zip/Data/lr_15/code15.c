#include <stdio.h>
void main()
 {  int b = 4;
    int a = b*12;
    int m = a *3;
    int n = m + 1;
    int * p;
    p = (int *)malloc(n*(sizeof(int)));
}