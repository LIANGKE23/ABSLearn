#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
int * l =(int *)malloc(7*sizeof(int));
char j ="PhcTp345";
printf("%c",j);
int * s;
int i = 15;
int c[23];
char LK[39];
int W = 2;
scanf("%d",&l);
char * y =(char *)malloc(2*sizeof(char));
int sz_E = W+i;
int * E =(int *)malloc(sz_E*sizeof(int));
scanf("%c",&y);
printf("%d",i);
int H[34];
int * o =(int *)malloc((W)*sizeof(int));
int x[34];
scanf("%c",&j);
char I[41];
scanf("%d",&o);
printf("%d",&E);
int F[10]={156,28,19,89,690,304,570,531,798,65};
int M;
int * LXY =(int *)malloc(9*sizeof(int));
}
