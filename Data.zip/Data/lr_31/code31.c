#include <stdio.h>
void main()
 {
    int c[6] = {1,2,3,5,12,3};
    int a = 5;
    printf("%d\n",c[2]);
    int * w;
    w = c + a - 4;
    printf("%d",w);
}