#include <stdio.h>
void main()
 {
    char c[5] = {'1','d','23','sa','00'};
    int a = -1;
    int sz = a + 6;
    printf("%c\n",c[1]);
    char * w;
    w = *c + a + 4;
    printf("%c",w);
}