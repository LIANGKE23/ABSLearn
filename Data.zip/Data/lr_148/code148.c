#include <stdio.h>
void main()
 {  
    int d = 2;
    int c = d*2;
    int b =c+5;
    int a = b+1;
    int b1[a*8];
    int *p = b1;
    printf("b:%d",&b1);
}