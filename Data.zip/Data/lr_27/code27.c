#include <stdio.h>
void main()
 {
    int l[5] = {1,2,12};
    printf("%d\n",l[1]);
    int * q = l;
    printf("%d",q);
}