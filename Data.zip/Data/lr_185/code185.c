#include <stdio.h>
 
int main(void)
{
    int    a = 10;
    int * pa = &a;
    float  b = 6.6;
    float * pb = &b;
    char   c = 'a'; 
    char *pc = &c;
   double d = 2.14e9;
   double *pd = &d;
  
    //最初的值
    printf("pa0=%d, pb0=%d, pc0=%d, pd0=%d\n", pa, pb, pc, pd);
    //加法运算
    pa += 2; 
   pb += 2; 
   pc += 2;
  pd += 2;
    printf("pa1=%d, pb1=%d, pc1=%d, pd1=%d\n", pa, pb, pc, pd);
    //减法运算
    pa -= 1; 
  pb -= 1; 
  pc -= 1;
  pd -= 1;
    printf("pa2=%d, pb2=%d, pc2=%d, pd2=%d\n", pa, pb, pc, pd);
 
    return 0;
}
