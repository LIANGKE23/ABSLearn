#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#define AMAX_NAME  128

#ifndef PI
#  define PI 3.141592653589793238
#endif

/*--------------------------------------------------------------------------*/ 

double *disp;
double *K;
double *v;

int main(int argc, char **argv)
{
  int i, j, k, disptplus = 4, pp;
  int Anext, Alast, col;
  int *ARCHmatrixindex;
  int *Acol;
  double sum0, sum1, sum2, sum3;
  disp = (double *) malloc( disptplus*sizeof(double));
  K = disp;
  v = (double *) malloc( j*sizeof(double));
  ARCHmatrixindex = v;
  Acol = (int *) malloc(Alast*sizeof(int));
  int rst;
  scanf("%d",&rst);
  if(rst > 5.5)
    return 0;
  else
    return 1;

}
/* --------------------------------------------------------------------------*/