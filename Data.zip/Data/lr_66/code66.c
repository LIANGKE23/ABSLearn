#include <stdio.h>
void main()
{
    int * p;
    int a;
    int b1[5] = {1,2,3};
    int b2[10] = {1,2,3,4,5};
    int b3[12] = {1,2,3,4,5};
    int sz;
    if (a>5){
        p = b1;
        sz = 5;
        printf("p:%d",*p);
    }
    else if (a<2){
        p = b2;
        sz = 10;
    }
    else{
    p = b3;
    sz = 12;
    }
    int *__attribute__((annotate("main:c&main:b3-alias/main:p-alias")))c = b3 + 5;
    printf("c:%d",*c);
}