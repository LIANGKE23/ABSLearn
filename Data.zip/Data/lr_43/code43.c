#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
int * K =(int *)malloc(29*sizeof(int));
printf("%d",&K);
int * A =(int *)malloc(26*sizeof(int));
printf("%d",&A);
scanf("%d",&K);
char * b =(char *)malloc(38*sizeof(char));
int u[12] = {1,3,12};
int aa = u[0];
printf("%d",&K);
char * O =(char *)malloc(aa*sizeof(char));
int U;
int r[7];
int e[37]={809,237,317,621,291,831,479,39,688,608,326,351,128,632,415,212,868,785,698,531,1,940,9,259,572,222,180,570,351,574,268,573,833,580,511,684,99};
char Y[22];
int * o = O;
int Q[13];
}