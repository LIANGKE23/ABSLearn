#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
	char * s =(char *)malloc(36*sizeof(char));
	int * K =(int *)malloc(16*sizeof(int));
	int H[22] = {1,3,12};
	scanf("%d",&K);
	char * B =(char *)malloc(48*sizeof(char));
	char p[39];
	int sz = H[1];
	char * r =(char *)malloc(sz*sizeof(char));
	char w;
}