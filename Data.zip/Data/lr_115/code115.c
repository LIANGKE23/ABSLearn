#include <stdio.h>
void main()
 {
    int a;
    printf("Input a: \n");
    scanf("%d",&a);
    int k = 2;
    int sz;
    while(k>10){
    	sz = a;
    	k = k + 1;
    }
    int * p;
    p = (int *)malloc((sizeof(int))*a);
}
