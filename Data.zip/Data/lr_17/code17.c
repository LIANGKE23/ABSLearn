#include <stdio.h>
void main()
 {  int b = 4;
    printf("%d",b);
    int a = b*b;
    int m = a *b;
    int n = m + (-1);
    int * p;
    p = (int *)malloc(n*(sizeof(int)));
}