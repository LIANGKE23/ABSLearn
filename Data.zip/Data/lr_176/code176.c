#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include<string.h>
void reverse(char *str)
{
	int len = strlen(str);//计算字符串长度
	char * left = str;
	char * right = str + len - 1;
	char tmp = 0;
    while(left<right)//左右交换字符
	{
		tmp = *left;
		*left = *right;
		*right = tmp;
		left++;
		right--;
	}
	
}
int main()
{
	char arr[] = "abcdefg";
	reverse(arr);
	printf("%s\n",arr);
	system("pause");
	return 0;
}
