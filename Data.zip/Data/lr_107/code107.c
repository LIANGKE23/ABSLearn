#include <stdio.h>
void main()
 {
    int n = 10;
    int sz = n;
    int * p;
    p = (int *)malloc(n*(sizeof(int)));
}