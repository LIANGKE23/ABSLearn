#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include<time.h>

void getnamein(char name[],int id)
{
	int i=id,len=0,a[20];
	while(i)
	{
		a[len++]=i%10;
		i/=10;
	}
	for(i=0;i<len;i++)
		name[len-1-i]='0'+a[i];
	name[len++]='.';
	name[len++]='i';
	name[len++]='n';
	name[len]='\0';
}
void getnameout(char name[],int id)
{
	int i=id,len=0,a[20];
	while(i)
	{
		a[len++]=i%10;
		i/=10;
	}
	for(i=0;i<len;i++)
		name[len-1-i]='0'+a[i];
	name[len++]='.';
	name[len++]='o';
	name[len++]='u';
	name[len++]='t';
	name[len]='\0';
}
void main()
{
	char in[100],out[100];
	int T,t,x,y;
	srand((unsigned)time(NULL));
	scanf("%d",&T);
	int * p =in;
	for(t=1;t<=T;t++)
	{
		getnamein(in,t);

		x=rand()%50;
		printf("%d\n",x);


		getnameout(out,t);
		if(x > 5)
			y =3 * x - 4;
		else
			y = 5 * x + 7;
		printf("%d\n",y);

	}
}