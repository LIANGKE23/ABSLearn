#include <stdio.h>
void main()
{
    int a = 5;
    int b1 = 6;
    int k;
    scanf("%d",&k);
    int * p;
    int sz;
    if (k>5){
        int szp = a+b1;
        p = (int *)malloc(szp*sizeof(int));
    }
    else if (k<2){
        p = (int *)malloc(k*sizeof(int));
    }
    else{
        p = (int *)malloc(12*sizeof(int));
        sz = 12;
        int * c = p;
    }
}