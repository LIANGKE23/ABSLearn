#include <stdio.h>
void main()
 {
    int c[25] = {1,2,3,5,12,3};
    printf("%d\n",c[21]);
    int sz = 1;
    int * a;
    a = *c + 4;
    printf("%d",a);
}