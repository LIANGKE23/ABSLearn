#include<stdio.h>
#include<stdlib.h>
int f(int *p, int sz){
    int *q =(int*)malloc(sz*sizeof(int));
    int * d = memcpy(q,p,sz*sizeof(int));
	return d;
}

int main( )
 {
 	int a[3] = {1,2,3};
 	int b[4] = {4,5,6,7};
	int t;
	printf("Input t: \n");
	scanf("%d",&t);
 	int size_c;
	int *c;
	if (t<10){
	      size_c = 3;
 	      c = f(a,size_c);}
    else{
	      size_c = 4;
 	      c = f(b,size_c);}
 	printf("%d",*c);
 	return 0;
 }