#include <stdio.h>
void main()
 {
    int a;
 	printf("Input a: \n");
    scanf("%d",&a);
     int b = 4;
    int x = a + b;
    int c[x];
    printf("%d\n",c[2]);
    int sz = x;
    int * w;
    w = c;
    printf("%d",w);
}
