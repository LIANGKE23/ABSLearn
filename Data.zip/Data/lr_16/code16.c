#include <stdio.h>
void main()
 {  int b = 4;
    printf("%d",b);
    int a = b+12;
    int m = a*12;
    int n = m + 1;
    printf("%d",n);
    int * p;
    p = (int *)malloc(n*(sizeof(int)));
}