#include <stdio.h>
void main()
{
    int a;
    int a1 = 1;
    scanf("%d",&a);
    int b = 6;
    int k;
    scanf("%d",&k);
    int * p;
    if (k>5){
    int sz = a+a1+1;
        p = (int *)malloc(sz*sizeof(int));
    }
    else if (k<2){
        p = (int *)malloc(b*sizeof(int));
        int * c = p;
    }
    else{
        p = (int *)malloc(12*sizeof(int));
    }
}