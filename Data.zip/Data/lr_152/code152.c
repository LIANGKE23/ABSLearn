#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

void mkc(FILE* code){
	char* c[] = {
				 "#include <stdio.h>\n",
				 "int main(int args, char* argv){\n",
				 "\t ////code here.\n",
				 "}"
				};				
	int j = 0;
	for (j;j<4;j++){
		fprintf(code,c[j]);
	}
}

void mkjava(FILE* code,char nametemp[]){
	char* java[] = {
					 "\n\tpublic static void main(String[] args){\n",
					 "\t\t////code here.\n",					 
					 "\t}\n",
					 "}"
					};
	fprintf(code,"public class %s{",nametemp);
	int j=0;
	for (j;j<4;j++){
		fprintf(code,java[j]);
	}	
}


main(int argv, char* args[]){
	if(!args[1]) {
		puts("You should name the file name.\n");
		exit(0);
	}

	FILE* code = fopen(args[1],"a");
	char nametemp[32];
	
	int i ;
	for(i=0;;i++){
		if (args[1][i]=='\0'){ 
			puts("You did not specify the extension name.");
			exit(0);
		}
		if (args[1][i]=='.'){ 
			nametemp[i]= '\0';
			break;
		}
		else{
			nametemp[i]=args[1][i];
		}
	}
	
	if (args[1][i+1]=='c' && args[1][i+2]=='\0')
		mkc(code);
	
	else if (args[1][i+1]=='j' && args[1][i+2]=='a'
		  && args[1][i+3]=='v' && args[1][i+4]=='a'
			&& args[1][i+5]=='\0')
		mkjava(code,nametemp);
		
	else {
		puts("Only C and Java!");
		exit(0);
	}
	if(!args[2]) {
		puts("You should specify the editer's name.Or you can open the file manually。\n");
		exit(0);
	}
	char * cmd;
	sprintf(cmd,"%s %s",args[2],args[1]);
	system(cmd);
}