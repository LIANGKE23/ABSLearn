#include <stdio.h>

struct network_t
{
    long *arcs;
    long *stop_arcs;
    long *dummy_arcs;
    long *stop_dummy; 
};

int main()
{
    struct network_t net;
    void *stop;
    int condition;
    long* arc;

    stop = (void *)net.stop_arcs;
    for( arc = net.arcs; arc != (long *)stop; arc++ ) {
        if( arc != 0 ) {
            if( condition ) 
                printf("hello world\n");
        }
    }
    return 0;
}