#include <stdio.h>
void main()
 {  int b = 4;
    printf("%d",b);
    int a = b+10;
    int m = a*10+1;
    int n = m;
    int * p = malloc(n*(sizeof(int)));
}