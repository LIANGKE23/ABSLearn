#include <stdio.h>
void main()
{
    int c;
    int abc=c;
    int q = 11;
    scanf("c: %d\n",c);
    if (c>12){
        abc = q;
    }
    int z=c+1;
    int h;
    scanf("h: %d\n",h);
    int a = c*q*z*h + (1+abc);
    int * k;
    int * p;
    int b1[a];
    int b2[h];
    if (a>5){
        p = b1;
        printf("p:%d",*p);
    }
    else if (a<2){
        p = b2;
    }
    else{
        p = k;
    }
    int * C = p;
    printf("c:%d",*C);
}