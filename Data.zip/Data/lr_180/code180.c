#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
 
int main()
{
	char ac[] = { 0,1,2,3,4,5,6,7,8,9 };                //声明一个char类型的数组
	char* p = ac;                                       //指针p为char*类型
	printf("p = %p\n", p);
	printf("p + 1 = %p\n", p + 1);                      //输出指针p+1的结果
	int ai[] = { 0,1,2,3,4,5,6,7,8,9 };                 //声明一个int类型的数组
	int* q = ai;                                        //指针q为int*类型
	printf("q = %p\n", q);
	printf("q + 1 = %p\n", q + 1);                      //输出指针q+1的结果
	printf("sizeof(char) = %d\n", sizeof(char));        //sizeof(char)的结果
	printf("sizeof(int) = %d\n", sizeof(int));          //sizeof(int)的结果
	return 0;
}
