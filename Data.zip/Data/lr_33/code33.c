#include <stdio.h>
void main()
 {
    char c[67] = {'1','d','a','s','x'};
    printf("%c\n",c[1]);
    char * w;
    int a = 12;
    w = (c + a);
    printf("%c",w+1);
}