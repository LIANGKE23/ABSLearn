#include <stdio.h>

int main(void) {

    int num[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    int *p = &num[0];
    int *q = &num[9];
    int temp;

    while (p < q) {
        temp = *p;
        *p = *q;
        p++;
        *p;
        *q = temp;
        q--;
        *q;
        printf("p = %p\nq = %p\ntemp = %d\n*p = %d\n*q = %d\n", p, q, temp, *p, *q);
        printf("%s", "num values: ");
        for (int i = 0; i < 10; ++i) {
            printf("%3d", num[i]);
        }
        puts("\n");
    }
}