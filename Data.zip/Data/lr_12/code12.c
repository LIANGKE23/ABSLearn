#include <stdio.h>
void main()
 {  int b = 12;
    int a = b + 1;
    int m = a;
    int n = m;
    int * p;
    p = (int *)malloc(n*(sizeof(int)));
}