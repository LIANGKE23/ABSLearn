#include <stdio.h>
void main()
 {
    int lxy[12];
    int sz = 12;
    int * q;
    q = lxy;
}