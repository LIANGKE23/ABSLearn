#include <stdio.h>
void main()
 {
    int a;
 	printf("Input a: \n");
    scanf("%d",&a);
    int b;
 	printf("Input b: \n");
    scanf("%d",&b);
    int q[] = {1,1,2,1};
    int u = b+a;
    int x = b;
    int c[x];
    int sz = u+a;
    int * h;
    h = (char*)malloc(sz*sizeof(char));
    int * w;
    w = c;
    printf("%d",w);
}
