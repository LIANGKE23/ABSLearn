#include <stdio.h>
void main()
 {
    int n = 10;
    int q[3] = {0,1};
    int sz = n + q[0];
    double * p;
    p = (double *)malloc((sizeof(double))*n);
}