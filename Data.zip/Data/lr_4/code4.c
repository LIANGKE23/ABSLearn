#include <stdio.h>
void main()
 {
    int n = 10;
    int n1 = 1;
    int n2 = 10;
    int * p;
    p = (int *)malloc(n*(sizeof(int)));
}