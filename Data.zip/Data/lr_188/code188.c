#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
// 
 struct  ptrflag {
   char  *pointer;
   unsigned  int  flag : 9;
};
 
void  func(unsigned  int  flag) {
   char  * ptr;
   char * ksks;
   ksks = ptr;
   struct ptrflag a;
   a.pointer = ptr;
   a.flag = flag;
} 