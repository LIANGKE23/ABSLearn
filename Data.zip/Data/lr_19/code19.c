#include <stdio.h>
void main()
 {
    char a[2] = {'abc', 'aaa'};
    char * q;
    q = a;
    int p = 2;
}