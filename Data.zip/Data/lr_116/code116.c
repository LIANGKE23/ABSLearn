#include <stdio.h>
void main()
 {
    int n = 10;
    int qq = n*12+1;
    float * p;
    p = (float *)malloc((sizeof(float))*n);
}