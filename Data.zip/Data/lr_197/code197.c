#include <stdio.h>
#include <stdlib.h>
#define MAX 10
char array_global[MAX];
int s_global = 2;
int * pointer;

 int f(){
    static int s_static_f = 2;
    static int array_static_f[MAX];
    static int * q1_f;
 }
f();

int main()
{
    int * p0 = (int*)malloc(s_global*sizeof(int));
    static int s_static = 2;
    static int array_static[MAX];
    static int * q1;
    int s = 4;
    int * p;
    p = malloc(s_static*sizeof(int));
    int * x = array_global;
    int * q =array_static;
    int array[s];
    int ab;
    int * pp;
    scanf("%d",&ab);
    if (ab > 10){
        pp = array;
    }
    else{
        pp = pointer;
    }
}