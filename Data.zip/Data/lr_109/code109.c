#include <stdio.h>
void main()
 {
    int n = 10;
    int sz = n + 1;
    double * p;
    p = (double *)malloc(n*(sizeof(double)));
}