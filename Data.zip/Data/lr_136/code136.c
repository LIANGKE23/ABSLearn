#include <stdio.h>
#include <stdlib.h>

int main() {
    char operator;
    double n1, n2;

    printf("Enter an operator (+, -, *, /): ");
    scanf("%c", &operator);
    printf("Enter two operands: ");
    scanf("%lf %lf",&n1, &n2);
    int * p;
    int a1[10] = {1,2,3,1,2,3};
    int a2[20] = {};
    int a3[30];
    int * m1 = (int *)malloc(12*sizeof(int));
    int size_p;

    switch(operator)
    {
        case '+':
            printf("%.1lf + %.1lf = %.1lf",n1, n2, n1+n2);
            p = a1;
            size_p = 10;
            break;

        case '-':
            printf("%.1lf - %.1lf = %.1lf",n1, n2, n1-n2);
            p = a2;
            size_p = 20;
            break;

        case '*':
            printf("%.1lf * %.1lf = %.1lf",n1, n2, n1*n2);
            p = a3;
            size_p = 30;
            break;

        case '/':
            p = m1;
            size_p = 12;
            printf("%.1lf / %.1lf = %.1lf",n1, n2, n1/n2);
            break;

        // operator doesn't match any case constant +, -, *, /
        default:
            printf("Error! operator is not correct");
    }

    return 0;
}