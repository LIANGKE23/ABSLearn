#include <stdio.h>
void main()
 {
    float b[2] = {1.2, 2.3};
    float * p = b + 1;
}