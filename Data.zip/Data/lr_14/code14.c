#include <stdio.h>
void main()
 {  int b = 2;
    int a = b*2;
    int m = a + 12;
    int n = m + 1;
    int * p;
    p = (int *)malloc(n*(sizeof(int)));
}