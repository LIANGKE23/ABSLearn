#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

//sahdiadbasd
int f(int * fp, int sz){
    int * fq =(int*)malloc(sz*sizeof(int*));//asdasdas
    int * fo = memcpy(fq,fp,sz);
    return fo;
}


int main(){
    /*asas*/
    int ct = 1;
    int bt =ct;
    int at = bt;
    int bt1[at];
    int ct1  = 2;
    int bt3 =ct1;
    int at1 = bt3;
    int bt2[at1];

    int * p;
    int * q;
    int a;/*asas*/int n = 20;
    int b1[5] = {1,2,3,4,5};
    int b2[10] = {11,2,3,4,5,6,7,8,9,10};
    int *b3 = (int *)malloc(n*sizeof(int*));
    printf("Input a: \n");
    scanf("%d",&a);
    int size_p;
    int size_c2;
    int k;
    int k2;
    for (k=0;k<15;k++){
        k2 = 1;
    }
    for (k=0;k<10;k++){
        k2 = 1;
    }
    int k1;
    int k3;
    for (k1=0;k1<10;k1++){
        k3 = 2;
    }
    while(k3 != 10){
    k3 = k3+1;
    }

    if(a<5){
        size_p = 5;}
    else if((a>=5)&(a<10)){
        size_p = 10;
    }
    else{
        size_p = 20;
    }
    
    if(a<5){
        p = b1+1;
        printf("p:%d",*p);
        
    }
    else if((a>=5)&(a<10)){
        p = b2;
        size_c2 = 5;
 	    q = f(b1,size_c2);
 	    printf("q: %d",*q);
    }
    else{
        size_c2 = 10;
 	    q = f(b2,size_c2);
        p = b3;
        printf("q: %d",*q);
    }
    int * c = p+2;
    printf("c:%d",*c);
}