#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned char byte;
typedef unsigned int uint;
#define B2IL(b) (((b)[0] & 0xFF) | (((b)[1] << 8) & 0xFF00) | (((b)[2] << 16) & 0xFF0000) | (((b)[3] << 24) & 0xFF000000))
#define B2IU(b) (((b)[3] & 0xFF) | (((b)[2] << 8) & 0xFF00) | (((b)[1] << 16) & 0xFF0000) | (((b)[0] << 24) & 0xFF000000))

#ifndef _IPIP_H_
#define _IPIP_H_

int init(const char* ipdb);

#endif //_IPIP_H_


char *strtok_r_2(char *str, char const *delims, char **context) {
    char *p;
    char *ret = NULL;

    if (str != NULL)
        context = str;

    if (*context == NULL)
        return NULL;

    ret = context;
    context = p;
    return ret;
}

int main() {
    init("ipip.datx");
    char * ip = "223.255.152.0";
    char result[128];
    printf("%s -> %s\n", ip, result);
    char *rst = NULL;
    char *lasts;
    rst = strtok_r_2(result, "\t", &lasts);
    while (rst) {
        printf("%s\n", rst);
        rst = strtok_r_2(NULL, "\t", &lasts);
    }
    return 0;
}