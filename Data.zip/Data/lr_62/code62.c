#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
char g[46];
int T;
scanf("%d",&T);
int * P =(int *)malloc(T*sizeof(int));
}