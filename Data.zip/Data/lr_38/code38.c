#include <stdio.h>
void main()
 {
     int a = 6;
    int x = a;
    int y = x;
    int z = y + 2;
    double c[y];
    double * w;
    w = &c;
}