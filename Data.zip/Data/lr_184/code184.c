#include <stdio.h>
#include <stdlib.h>
 
int main()
{
    int a[] = {1,2,3};
    int i;
    int *pr = NULL;
    pr = &a;
    int length = sizeof(a)/sizeof(int);
    printf("从0开始输出:\n");
    for(i =0;i<length;i++)
    {
 
        printf("a[%d]: %d\n",i,a[i]);
        printf("%d\n",*pr);
        pr++;
    }
    printf("从length-1开始输出:\n");
    int *pr_ = NULL;
    pr_ = a+length-1;
 
    for(i =0;i<length;i++)
    {
        printf("a[%d]: %d\n",i,a[i]);
        printf("%d\n",*pr_);
        pr_--;
    }
    return 0;
}
