#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
	char k[39];
	char c;
	char P[41];
	int N[32];
	int h = 2;
	int e[4] = {0,1,2};
	char * S =(char *)malloc(4*sizeof(char));
	int B[32];
	int l[]={575,360,527,572,17};
	char u ="S";
	int sz_i = h*32;
	int sz_t = e[1]*5;
	char * i =(char *)malloc(sz_i*sizeof(char));
	char * t =(char *)malloc(sz_t*sizeof(char));
}
