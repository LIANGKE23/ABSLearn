#include <stdio.h>
void main()
 {
    int n = 10;
    int sz;
    int * p;
    p = (int *)malloc(n*(sizeof(int)));
}