#include<stdio.h>
#include<stdlib.h>
struct s{
	int*p;
	int sz;
	int b[6];};

int* f(int sz){
    int i;
    int* p = (int*)malloc(sizeof(int)*sz);
    struct s np;
    int b[sz];
    for(i=0;i<sz;i++){
        p[i] = i;}
    np.p = p;
    np.sz = sz;
    return p;}

int main(){
    int *p;
    int a;
    int size;
    int b1[5] = {1,2,3,4,5};
    int b2[10] = {11,22,33,44,55,66,77,88,99,00};
    printf("Input integer a:");
    scanf("%d",&a);
    if (a<5){
        size = 5;
        p = b1;}
    else if ((a>=5)&(a<10)){
        size = 10;
        p = b2;}
    else{
        size = 15;
        struct s np;
        np.p = f(size);
        p = np.p;
        printf("%d\n",np.sz);
    }
    int* c = p+1;
    printf("P: %d\n",*p);
    printf("C: %d",*c);}