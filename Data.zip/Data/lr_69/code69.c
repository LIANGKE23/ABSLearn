#include <stdio.h>
void main()
{
    int x = 3;
    int ha[x];
    if (x>3){
    ha[1] = 1;
    }
    else{
    ha[1] = 3;
    }
    int q = 12;
    int a = 5 * q;
    int b1[5] = {1,2,3};
    int b2[a];
    int sz =x;
    int * p = ha;
    if (a>5){
        p = b1;
        sz = 5;
        printf("p:%d",*p);
    }
    else if (a<2){
        p = b2;
        sz = a;
    }
    int * c = b1 + 5;
    printf("c:%d",*c);
}