#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
	int k;
	char c[23];
	int h[18];
	int i[49]={1,475};
	int J[28];
	scanf("%c",c[0]);
	int sz_D = 1+i[0];
	int * D =(int *)malloc(sz_D*sizeof(int));
}