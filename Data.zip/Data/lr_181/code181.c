#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
 
int main()
{
	char ac[] = { 0,1,2,3 };
	int len = 4;
	char* p = ac;
	int tag = 1;                                           //标志位
	for (int i = 0; i < len; i++)
	{
		if (ac[i] != *(p + i))
		{
			tag = 0;
			break;
		}
	}
	if (tag == 1)
	{
		printf("OK\n");
	}
	else
	{
		printf("ERROR\n");
	}
	return 0;
}
