#include<stdio.h>
#include<string.h>
int length(char*p)
{
int n = 0;
while (*p !='\0')
{
n++;               //长度加1
p++;               //指针后移一位
}
return n;
}

int main(void)
{
    int len;
    char a[100];
    memset(a, 0x00, 100);
    puts("请输入一个字符串:");
    gets(a);
    len = length(a);
    printf("字符串长度为：%d\n", len);
    return 0;
}
