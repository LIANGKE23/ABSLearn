#include <stdio.h>
void main()
{
    int * p;
    int a;
    int b1[5] = {1,2,3};
    int b2[10] = {1,2,3,4,5};
    if (a>5){
        p = b1;
        printf("p:%d",*p);
    }
    else{
        p = b2;
    }
    int * c = b2 + 5;
    printf("c:%d",*c);
}
