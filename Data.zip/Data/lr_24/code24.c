#include <stdio.h>
void main()
{
    float y[] = {1.12,12.213, 2.32};
    float * lk = y + 1;
}