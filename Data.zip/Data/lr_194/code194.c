#include <stdio.h>
#include <stdlib.h>
int f(int a,int sz){
int * b = a;
return b;
}
int main(){
int a[5];
int sz = 5;
int * p = f(a,sz);
}