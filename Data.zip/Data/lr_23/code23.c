#include <stdio.h>
void main()
 {
    char a[] = {'as', 'sx','lk','lxy'};
    char * q;
    int k = 1;
    q = a;
}