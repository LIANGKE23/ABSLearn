#include <stdio.h>
void main()
 {
    int a;
    printf("Input a: \n");
    scanf("%d",&a);
    int q[] = {1,1,2,1};
    int b = 4*a;
    int x = b+q[2];
    int c[x];
    printf("%d\n",c[2]);
    int sz;
    int * w;
    w = c;
    printf("%d",w);
}
