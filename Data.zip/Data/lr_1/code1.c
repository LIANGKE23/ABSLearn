#include <stdio.h>
void main()
 {
    int n = 10;
    int * p;
    p = (int *)malloc((sizeof(int))*n);
}