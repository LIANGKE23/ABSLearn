#include <stdio.h>
void main()
 {
    int n = 10;
    int n1 = 1;
    int n2 = 0;
    int n3 = 2*n1;
    int * p;
    p = (int *)malloc(n*(sizeof(int)));
}