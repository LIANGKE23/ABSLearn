#include <stdio.h>
void main()
 {
    int b[2] = {1, 2};
    int sz = 2;
    int * p;
    p = b;
}