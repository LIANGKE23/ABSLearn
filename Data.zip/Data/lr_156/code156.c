#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>

move(int * array,int n,int m)
{
	int * p;
	p = array;
	int *  array_end;
	array_end=*(array+n-1);
}


void main(){
	int number[20];
	int n=10;
	int m=2;
	int i;
	int N = 10;
	printf("the total numbers is:");
	scanf("%d",&n);
	printf("back m:");
	scanf("%d",&m);
	for(i=0;i<N-1;i++){
		scanf("%d,",&number[i]);
		scanf("%d",&number[n-1]);
		move(number,n,m);
	}
	for(i=0;i<N-1;i++){
		printf("%d,",number[i]);
		printf("%d",number[n-1]);
	}
}
