#include <stdio.h>
void main()
{
    int * p;
    int a = 5;
    int b1[5] = {1,2,3};
    int b2[a];
    int b3[12];
    if (a>5){
        p = b1;
        printf("p:%d",*p);
    }
    else if (a<2){
        p = b2;
    }
    else{
    p = b3;
    int q = 10;
    a = q;
    }
    int * c = p;
}