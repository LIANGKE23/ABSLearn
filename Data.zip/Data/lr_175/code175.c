#include <stdio.h>
void  print(int *arr,int length)//传参
{
	int *p = arr;
	int i = 0;
	for (i = 0; i < length; i++)
	{
		printf("%d  ", *(p + i));
	}
}

int main()
{
	int arr[] = { 1,2,3,4,5,6,7,8,9,10 };
	int length = sizeof(arr) / sizeof(arr[0]);//计算数组的个数
	print(arr,length);
	system("pause");
	return 0;
}
