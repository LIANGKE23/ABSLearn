#include <stdio.h>
void main()
{
    int a = 5;
    int q = a + 1;
    int k;
    scanf("%d",&k);
    int * p;
    int * c = p;
    int sz1;
    int sz2;
    if (k>5){
        p = (int *)malloc(q*sizeof(int));
    }
    else if (k<2){
        p = (int *)malloc(a*sizeof(int));
        sz1 = a;
        sz2 = a;
    }
    else{
        p = (int *)malloc(k*sizeof(int));
        sz1 = k;
        sz2 = k;
    }
}