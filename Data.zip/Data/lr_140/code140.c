#include <stdio.h>
#include <stdlib.h>
int main()
{
    int a[5] = {1, 2, 3, 4, 5};
    int sz = 10;
    for(int i;i<sz;i++)
    {
        int * p = a;
        a[i] = i;
    }
    return 0;
}