#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
 
int main()
{
	char ac[] = { 0,1,2,3,4,5,6,7,8,9 };
	int ai[] = { 0,1,2,3,4,5,6,7,8,9 };
	printf("第一种打印：\n");                           //第一种：使用int i循环进行遍历
	for (int i = 0; i < sizeof(ac) / sizeof(ac[0]); i++)
	{
		printf("%d\t", ac[i]);
	}
	printf("\n第二种打印：\n");                         //第二种：使用int* p循环进行遍历
	for (char* p = ac; p < ac + sizeof(ac) / sizeof(ac[0]);)
	{
		printf("%d\t", *p++);
	}
	return 0;
}
