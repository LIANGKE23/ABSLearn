#include <stdio.h>
void main()
 {
    int c[] = {1,2,3,5,12,3};
    int b = 1;
    printf("%d\n",c[2]);
    int * a;
    a = c + b + 4;
    printf("%d",*a);
}