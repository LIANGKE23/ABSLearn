#include<stdio.h>
#include <stdbool.h>
int max(int, int);
int main() {
    int a[4] = { 1,2,3,4 };
    int* p1 = a;
    int* p2 = &a[2];
    bool p = p2>p1;
    printf("p的值是：%d\n", p);
    system("pause");
    return 0;
}