#include <stdio.h>
void main()
{
    int x;
    scanf("x:%d\n",x);
    int ha[x];
    if (x>3){
    ha[1] = 1;
    }
    else{
    ha[1] = 3;
    }
    int q = ha[1];
    int a = 5 * q;
    int b1[5] = {1,2,3};
    int b2[a];
    int b3[12];
    int * p;
    if (a>5){
        p = b1;
        printf("p:%d",*p);
    }
    else if (a<2){
        p = b2;
    }
    else{
    p = b3;
    }
    int * c = b2 + 5;
    printf("c:%d",*c);
}