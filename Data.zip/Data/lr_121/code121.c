#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
	int e;
	scanf("%d",&e);
	char X[26];
	int sz = e;
	int i[41]={255,274,42,898,878,306,21,836,501,790,469,594,470,56,163,375,9,899,549,463,983,440,702,82};
	char * q =(char *)malloc(e*sizeof(char));
	int * p = i;
	int sz1 = 41;
}