#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main(){
int v;
scanf("%d",v);
int * y =(int *)malloc(v*sizeof(int));
printf("%d",&y);
int a = v;
int Q[44];
int * D = y + 1;
int * z;
 z = D + 1;
}