#include <stdio.h>
void main()
 {
    int p =21;
    char d[15];
    int sz;
    scanf("%d",&sz);
    printf("%d\n",p);
    char * q;
    int a = 12;
    q = *(d + a);
    printf("%c",q-1);
}