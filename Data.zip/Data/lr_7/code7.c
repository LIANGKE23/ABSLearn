#include <stdio.h>
void main()
 {
    int n = 10;
    int n1 = n;
    int * p;
    p = (int *)malloc(n*(sizeof(int)));
}